function x =Awshrink(X_tensor,x,rho,p,sX,isWeight,mode,Iteration) 
% X_tensor : initialized tensor solution
if nargin<8 
    Iteration = 1;
end
if mode == 1
    Y=X2Yi(X_tensor,3);
elseif mode == 3
    Y=shiftdim(X_tensor, 1);
else
    Y = X_tensor;
end
for i =1:Iteration
    w = zeros(min(size(Y,1),size(Y,2)),1);
    Yhat = fft(Y,[],3);
    for j = 1:size(Yhat,3)
        [~,shat,~] = svd(full(Yhat(:,:,j)),'econ');
        for k = length(w)
            w(k) = w(k)+shat(k);
        end
    end
%     w = 2*w.^(1-p/2);
%     w = 1./(w+1e-3);

%     tp1 = 1 + w.^p;
%     tp2 = p*(w.^(p-1));
%     w = tp2.*1e+6/tp1;

     %1  1-exp(-Sp)对S
     w = p*exp(-w.*p);
%      w = p*(w.^(p-1))*exp(-w.^p)
%       w = (w.^p)*log(w.)
     %2   1-exp(-p/S)
%     w = exp(-p./w)/w;%全0
%     w = (-p*exp(-p./w))/w.^2;%全inf

    [x,~] = WshrinkObj_weight(x,w*rho,sX, isWeight,mode);
     X_tensor = reshape(x, sX);
    if mode == 1
       Y=X2Yi(X_tensor,3);
    elseif mode == 3
      Y=shiftdim(X_tensor, 1);
    else
      Y = X_tensor;
   end
end
end