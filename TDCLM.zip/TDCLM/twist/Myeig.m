function [G] = Myeig(KH,n )
numker = size(KH,3);
num=size(KH,1);
G=zeros(num,n,numker);

for i=1:numker
    [V,D]=eig(KH(:,:,i));
    [d, ind] = sort(diag(D), 'descend');
    D = D(ind(1:n), ind(1:n));
    V = V(:, ind(1:n));
    A=sqrtm(D);
   G(:,:,i)=V*A;
end


end

