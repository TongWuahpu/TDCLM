clear;
addpath('tSVD','proxFunctions','solvers','twist','data','tools');
addpath('ClusteringMeasure', 'LRR', 'Nuclear_norm_l21_Algorithm', 'unlocbox');

load('3-sources.mat');
gt = truth;
gt = double(gt);
cls_num = length(unique(gt));
X{1} = bbc'; X{2} = guardian'; X{3} = reuters';
 for v=1:3
    [X{v}]=NormalizeData(X{v});
 end

% Initialize...
K = length(X); N = size(X{1},2); 

lambda1 = 1;
lambda2 = 0.8;

%--------------initialize----------------% 
S = zeros(N,N);
for k=1:K
    C{k} = zeros(N,N); 
    E{k} = zeros(size(X{k},1),N); 
    Y1{k} = zeros(size(X{k},1),N); 
    XTX{k} = X{k}'*X{k};
end
for k=1:K+1
    W{k} = zeros(N,N);
    G{k} = zeros(N,N);
    Z{k} = zeros(N,N);
end

I = eye(N,N);
w = zeros(N*N*K+1,1);
g = zeros(N*N*K+1,1);
dim1 = N;dim2 = N;dim3 = K+1;
myNorm = 'tSVD_1';
sX = [N, N, K+1];
%set Default
parOP         =    false;
ABSTOL        =    1e-6;
RELTOL        =    1e-4;
Isconverg = 0;epson = 1e-7;
iter = 0;
mu = 10e-4; max_mu = 10e12; pho_mu = 2;
rho = 0.0001; max_rho = 10e12; pho_rho = 2;
tic;

while(Isconverg == 0)
    fprintf('----processing iter %d--------\n', iter+1);      
        
        %1 update S--C{K+1}   D   L
        tmp1 = 0;
        tmp2 = 0;
        for k=1:K 
            tmp1 = tmp1 + mu*XTX{k};
            tmp2 = tmp2 + lambda1*(C{k}*C{k}') + X{k}'*Y1{k} + mu*XTX{k} - mu*XTX{k}*C{k} - mu*X{k}'*E{k};
        end
        S = pinv(tmp1 + rho*I)*(tmp2 - W{K+1} + rho*G{K+1});
        C{K+1} = S;

        %2 update D
        S = (S+S')/2;                                                          
        D = diag(sum(S));

        %3 update L
        L = D - S;

        %4 update C{k}
        for k=1:K
            tmp3 = lambda1*L/2 + lambda1*L'/2 + mu*XTX{k} + rho*I;
            tmp4 = X{k}'*Y1{k} + mu*XTX{k} - mu*XTX{k}*S - mu*X{k}'*E{k} - W{k} + rho*G{k};
            C{k} = pinv(tmp3)*tmp4;
        end

        %5 update E{k} 
        for k=1:K
            tmp5 = Y1{k} + mu*X{k} - mu*X{k}*S - mu*X{k}*C{k};
            tmp6 = 2*I + mu*I;
            E{k} = tmp5*pinv(tmp6);
        end   
     
         %6 update Y1{k}
         for k=1:K
             Y1{k} = Y1{k} + mu*(X{k} - X{k}*S - X{k}*C{k} - E{k});
         end

         %7 update Z{k}
         for k=1:K+1
             Z{k} = C{k};
         end

         %8 update G_tensor
         Z_tensor = cat(3, Z{:,:});
         W_tensor = cat(3, W{:,:});
         z = Z_tensor(:);
         w = W_tensor(:);
         [g, ~] = wshrinkObj(z + 1/rho*w,lambda2/rho,sX,0,3);
         G_tensor = reshape(g, sX);

         %9 update W
         w = w + rho*(z - g);
    %% coverge condition
    Isconverg = 1;
    for k=1:K
        if (norm(X{k} - X{k}*S - X{k}*C{k} - E{k},inf)>epson)
            history.norm_1 = norm(X{k} - X{k}*S - X{k}*C{k} - E{k},inf);
            fprintf('    norm_1 %7.10f    ', history.norm_1);
            Isconverg = 0;
        end
    end
    for k=1:K+1
        G{k} = G_tensor(:,:,k);
        W_tensor = reshape(w, sX);
        W{k} = W_tensor(:,:,k);
        if (norm(Z{k}-G{k},inf)>epson)
            history.norm_Z_G = norm(Z{k}-G{k},inf);
            fprintf('norm_Z_G %7.10f    \n', history.norm_Z_G);
            Isconverg = 0;
        end
    end 
    if (iter>200)
        Isconverg  = 1;
    end
    iter = iter + 1;
    mu = min(mu*pho_mu, max_mu);
    rho = min(rho*pho_rho, max_rho);
end

S1 = 0;
for k=1:K+1
    S1 = S1 + abs(Z{k})+abs(Z{k}');
end
pre_labels_C = SpectralClustering(S1,cls_num);
ACC = Accuracy(pre_labels_C,double(gt))*100;
fprintf('lambda1 %.5f lambda2 %.5f ACC %.2f \n', lambda1,lambda2,ACC);
toc;



 




